from pathlib import Path
import subprocess, shutil, sys
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ROOT = Path(__file__).resolve().parent
ASSET = ROOT / "assets" / "storyboard.png"
SCENES = ROOT / "scenes"
OUTPUT = ROOT / "output" / "episode_01.mp4"
SCENES.mkdir(exist_ok=True)
OUTPUT.parent.mkdir(exist_ok=True)

# Narasi/caption ringkas per adegan (Bahasa Indonesia)
CAPTIONS = [
    "Pada suatu pagi, Lilo berjalan-jalan di hutan.",
    "Wah! Lilo menemukan wortel yang sangat besar!",
    "Tiba-tiba, wortel itu mengeluarkan cahaya ajaib.",
    "Wortel ajaib menyapa Lilo.",
    "Lilo ingin menyimpan wortel itu sendiri.",
    "Namun, ia melihat teman-temannya kelaparan.",
    "Lilo pun membagikan wortel kepada semua teman.",
    "Berbagi membuat kita semua bahagia!"
]
DURATIONS = [6, 7, 7, 6, 7, 7, 8, 7]  # total 55 detik

def find_font():
    options = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf"
    ]
    for p in options:
        if Path(p).exists():
            return p
    return None

def make_vertical_panel(panel, caption, out_path):
    # Crop to vertical 9:16, retaining the center of each storyboard cell.
    w, h = panel.size
    target_ratio = 9 / 16
    if w / h > target_ratio:
        nw = int(h * target_ratio)
        left = (w - nw) // 2
        panel = panel.crop((left, 0, left + nw, h))
    else:
        nh = int(w / target_ratio)
        top = max(0, (h - nh) // 2)
        panel = panel.crop((0, top, w, top + nh))
    panel = panel.resize((1080, 1920), Image.Resampling.LANCZOS).convert("RGB")

    # Add a readable caption band with a soft dark background.
    overlay = Image.new("RGBA", panel.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)
    font_path = find_font()
    font = ImageFont.truetype(font_path, 52) if font_path else ImageFont.load_default()
    words = caption.split()
    lines, current = [], ""
    for word in words:
        trial = (current + " " + word).strip()
        if draw.textbbox((0,0), trial, font=font)[2] > 940 and current:
            lines.append(current)
            current = word
        else:
            current = trial
    if current:
        lines.append(current)
    line_h = 68
    band_h = line_h * len(lines) + 70
    y0 = 1920 - band_h - 90
    draw.rounded_rectangle((55, y0, 1025, y0 + band_h), radius=35, fill=(0,0,0,165))
    y = y0 + 30
    for line in lines:
        bbox = draw.textbbox((0,0), line, font=font, stroke_width=2)
        x = (1080 - (bbox[2]-bbox[0])) // 2
        draw.text((x, y), line, font=font, fill="white", stroke_width=3, stroke_fill="black")
        y += line_h
    final = Image.alpha_composite(panel.convert("RGBA"), overlay).convert("RGB")
    final.save(out_path, quality=95)

def main():
    if not ASSET.exists():
        print("Storyboard tidak ditemukan:", ASSET)
        sys.exit(1)
    if not shutil.which("ffmpeg"):
        print("FFmpeg belum tersedia. Jalankan: sudo apt-get update && sudo apt-get install -y ffmpeg")
        sys.exit(1)

    img = Image.open(ASSET).convert("RGB")
    # Storyboard generated as 2 columns x 4 rows.
    cell_w, cell_h = img.width // 2, img.height // 4
    for i in range(8):
        col, row = i % 2, i // 2
        cell = img.crop((col*cell_w, row*cell_h,
                         (col+1)*cell_w, (row+1)*cell_h))
        make_vertical_panel(cell, CAPTIONS[i], SCENES / f"scene_{i+1:02d}.jpg")

    # Render each still as a gently moving video clip, then concatenate.
    clips = []
    for i, duration in enumerate(DURATIONS, 1):
        image_path = SCENES / f"scene_{i:02d}.jpg"
        clip_path = SCENES / f"clip_{i:02d}.mp4"
        frames = duration * 30
        # zoompan creates a subtle cinematic movement; output remains 1080x1920.
        vf = f"zoompan=z='min(zoom+0.00035,1.08)':d={frames}:s=1080x1920:fps=30"
        cmd = ["ffmpeg", "-y", "-loop", "1", "-i", str(image_path),
               "-vf", vf, "-t", str(duration), "-r", "30",
               "-c:v", "libx264", "-pix_fmt", "yuv420p", str(clip_path)]
        subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        clips.append(clip_path)

    concat_file = SCENES / "concat.txt"
    concat_file.write_text("".join(f"file '{p.resolve()}'\n" for p in clips), encoding="utf-8")
    subprocess.run(["ffmpeg", "-y", "-f", "concat", "-safe", "0",
                    "-i", str(concat_file), "-c", "copy", str(OUTPUT)],
                   check=True)
    print(f"\nSELESAI! Video tersimpan di: {OUTPUT}")
    print("Durasi sekitar 55 detik, format vertikal 1080x1920 MP4.")
    print("Catatan: versi awal memakai gambar + caption + gerakan kamera; narasi suara/musik bisa ditambahkan pada tahap berikutnya.")

if __name__ == "__main__":
    main()
